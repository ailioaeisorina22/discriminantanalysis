import pandas as pd
import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from scipy.stats import f
from functii import *
from grafice import *
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB

import matplotlib
matplotlib.use('TkAgg')  # Backend pentru ferestre externe


tabel_antrenare_testare = pd.read_csv("data_in/Cardiovascular_Disease_Dataset.csv", index_col=0)
#print(tabel_antrenare_testare)

nan_replace_t(tabel_antrenare_testare)
#print(tabel_antrenare_testare)

variabile = list(tabel_antrenare_testare)
predictori = variabile[:-1] #vb independente
tinta = variabile[-1] #vb dependenta

#divizare in set de invatare si set de testare
#train - 60%, test - 40%
x_train, x_test, y_train, y_test = (
    train_test_split(
        tabel_antrenare_testare[predictori],
        tabel_antrenare_testare[tinta],
        test_size=0.4)
)
#print(x_train, y_train)

#Construire model liniar
model_lda = LinearDiscriminantAnalysis()
model_lda.fit(x_train, y_train)

#Calculul puterii de discriminare a predictorilor
clase = model_lda.classes_
G = model_lda.means_

n = len(x_train)
m = len(predictori)
q = len(clase)
g = G - np.mean(x_train.values, axis=0)
dg = np.diag(model_lda.priors_)
t = np.cov(x_train.values, rowvar=False) #matricea de covarianta totala
b = g.T @ dg @ g #matricea de covarianta inter clase
w= t-b #matricea de covarianta intra clase

f_predict = (np.diag(b)/(q-1))/(np.diag(w)/(n-q)) #putere discriminare predictori
#print(f_predict)

#test Fisher
p_values = 1 - f.cdf(f_predict, q - 1, n - q)
print(p_values)

tabel_predictori = pd.DataFrame(
data={
        "Predictori":predictori,
        "PutereDiscriminare": f_predict,
        "P_Values": p_values
     })
tabel_predictori.to_csv("data_out/Predictori.csv", index=False)

#analiza discriminatori pe setul de antrenare
nr_discriminatori = min(q-1, m) #nr functii discriminante
#print(nr_discriminatori)

#preluare scoruri discriminante pe setul de antrenare
z = model_lda.transform(x_train)
etichete_z = ["Z" + str(i+1) for i in range(nr_discriminatori)]
#salvare scoruri discriminante
tz = pd.DataFrame(z, x_train.index, etichete_z)
tz.to_csv("data_out/z.csv")

# Calcul putere discriminare discriminatori pe setul de antrenare
t_z = np.cov(z,rowvar=False) #matricea de covarianta totala
z_ = np.mean(z,axis=0)
G_df = pd.DataFrame(G, columns=predictori)
G_z = model_lda.transform(G_df)
dg = np.diag(model_lda.priors_)
b_z = (G_z - z_).T @ dg @ (G_z - z_) # matricea de covarianta inter-clase
w_z = t_z - b_z # matricea de covarianta intra-clase
f_discriminatori = (np.diag(b_z) / (q - 1)) / (np.diag(w_z) / (n - q)) #puterea de discriminare a variabilelor discriminante


#Test Fisher
p_value_z = 1 - f.cdf(f_discriminatori, q-1, n - q)
print(p_value_z)

t_discriminatori = pd.DataFrame(
    {"PutereDiscriminare": f_discriminatori,
            "P_value":p_value_z
            },
    etichete_z
)
t_discriminatori.to_csv("data_out/Discriminatori.csv", index_label="Discriminatori")
#vizualizare distributie discriminatori
for i in range(nr_discriminatori):
    plot_distributie(z, y_train, i) #??????

#calcul centrii discriminatori
# Calcul centrii discriminatori
print(nr_discriminatori)
zg = tz.groupby(by=y_train.values).mean().values
# Vizualizare instante si centrii după axele discriminante
if nr_discriminatori > 1:
    for i in range(nr_discriminatori - 1):
        for j in range(i + 1, nr_discriminatori):
            scatterplot(z, zg, y_train, clase, i, j)
else:
    print("Număr insuficient de discriminatori pentru a plota.")
    plot_single_discriminator(z, y_train, clase, k=0) #histograma

#Testare model
predictie_lda_test = model_lda.predict(x_test)
metrici_lda = calcul_metrici(y_test, predictie_lda_test, clase)
metrici_lda[0].to_csv("data_out/MatriceaDeConfuzie_LDA.csv", index_label="Target")
metrici_lda[1].to_csv("data_out/Acuratete_LDA.csv", index=False)

salvare_erori(y_test, predictie_lda_test, tinta, x_test.index, "LDA")
#Aplicare model
set_aplicare = pd.read_csv("data_in/Cardiovascular_Disease_no_target.csv", index_col=0)
predictie_lda = model_lda.predict(set_aplicare[predictori])
set_aplicare["Predictie LDA"] = predictie_lda
#print(set_aplicare)

#Modelul bayesian
model_bayes = GaussianNB()
model_bayes.fit(x_train, y_train)

#Testare
predictie_test_bayes = model_bayes.predict(x_test)
metrici_b = calcul_metrici(y_test, predictie_test_bayes, clase)
metrici_b[0].to_csv("data_out/MatriceaDeConfuzie_Bayes.csv", index_label="Target")
metrici_b[1].to_csv("data_out/Acuratete_Bayes.csv", index=False)
salvare_erori(y_test, predictie_test_bayes, tinta, x_test.index, "Bayes")
# Aplicare model
predictie_b = model_bayes.predict(set_aplicare[predictori])
set_aplicare["Predictie Bayes"] = predictie_b

set_aplicare.to_csv("data_out/Predictii.csv")

