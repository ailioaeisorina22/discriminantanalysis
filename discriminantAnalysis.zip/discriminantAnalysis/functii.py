import pandas as pd
import numpy as np
from pandas.api.types import is_numeric_dtype
from sklearn.metrics import confusion_matrix, cohen_kappa_score

def nan_replace_t(t):
    assert isinstance(t, pd.DataFrame)
    for v in t.columns:
        if any(t[v].isna()):
            if is_numeric_dtype(t[v]):
                t.fillna({v: t[v].mean()}, inplace=True)
            else:
                t.fillna({v: t[v].mean()}, inplace=True)

def calcul_metrici(y, predictie, clase):
    c = confusion_matrix(y, predictie)
    tabel_c = pd.DataFrame(c, clase, clase)
    tabel_c["Acuratete"] = np.round(np.diag(c) * 100 / np.sum(c, axis=1), 3)
    acuratete_medie = tabel_c["Acuratete"].mean()
    acuratete_globala = np.round(sum(np.diag(c)) * 100 / len(y), 3)
    index_CKappa = cohen_kappa_score(y, predictie)
    acuratete = pd.DataFrame(data={
        "Acuratete globala": [acuratete_globala],
        "Acuratete medie": [acuratete_medie],
        "Index Cohen-Kappa": [index_CKappa]
    })
    return tabel_c, acuratete

def salvare_erori(y, predictie, tinta, nume_instante, model):
    tabel = pd.DataFrame(
        data={
            tinta: y,
            "Predictie": predictie
        }, index=nume_instante
    )
    tabel[y != predictie].to_csv("data_out/err_" + model + ".csv")