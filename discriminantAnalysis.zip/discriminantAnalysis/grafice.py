import matplotlib.pyplot as plt
from seaborn import kdeplot, scatterplot
import numpy as np

def plot_distributie(z, y, k=0):
    fig = plt.figure(figsize=(9, 6))
    ax = fig.add_subplot(1, 1, 1)
    ax.set_title("Distributie in axa discriminanta " + str(k + 1))
    kdeplot(x=z[:, k], hue=y, fill=True, ax=ax)
    plt.savefig("Distributie_in_axa_discriminanta_" + str(k + 1))

def scatterplot_g(z, zg, y, clase, k1=0, k2=1):
    fig = plt.figure(figsize=(9, 6))
    assert isinstance(fig,plt.Figure)
    ax = fig.add_subplot(1, 1, 1, aspect=1)
    assert isinstance(ax,plt.Axes)
    ax.set_title("Plot instante si centrii in axele discriminante")
    ax.set_xlabel("z" + str(k1 + 1))
    ax.set_ylabel("z" + str(k2 + 1))
    q = len(clase)
    for i in range(q):
        x_ = z[y == clase[i], k1]
        y_ = z[y == clase[i], k2]
        ax.scatter(x_, y_, label=clase[i])
    ax.scatter(zg[:, k1], zg[:, k2], alpha=0.5, s=200, marker="s")
    ax.legend()
    plt.savefig("PlotInstanteSiCentriiInAxeleSiscriminante")

def plot_single_discriminator(z, y, clase, k=0):
    plt.figure(figsize=(8, 6))
    for i in range(len(clase)):
        plt.hist(z[y == clase[i], k], bins=30, alpha=0.5, label=f'Clasa {clase[i]}')
    plt.xlabel(f"Discriminator {k+1}")
    plt.ylabel("Frecvență")
    plt.legend()
    plt.title(f"Distribuția scorurilor discriminatorului {k+1}")
    plt.savefig("DistributiaScorurilorDiscrimatorului1")
    plt.show()

def show():
    plt.show()
